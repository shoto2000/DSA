package com.skillovilla.Service;

import com.skillovilla.Model.Book;

public interface BookService {
    public Book addBook(Book book);
}
