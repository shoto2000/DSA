package com.skillovilla;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SkilloVillaApplication {

	public static void main(String[] args) {
		SpringApplication.run(SkilloVillaApplication.class, args);
	}

}
